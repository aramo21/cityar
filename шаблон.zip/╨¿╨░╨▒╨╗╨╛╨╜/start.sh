#!/bin/bash

echo "🚀 Запуск Real Estate Website"
echo "=============================="

# Проверяем Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js не установлен. Установите Node.js v16+ с официального сайта."
    exit 1
fi

# Проверяем npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm не найден. Переустановите Node.js."
    exit 1
fi

echo "✅ Node.js $(node --version) найден"
echo "✅ npm $(npm --version) найден"

# Устанавливаем зависимости
if [ ! -d "node_modules" ]; then
    echo "📦 Устанавливаем зависимости..."
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ Ошибка при установке зависимостей"
        exit 1
    fi
    echo "✅ Зависимости установлены"
else
    echo "✅ Зависимости уже установлены"
fi

# Проверяем конфигурацию
if [ ! -f ".env" ]; then
    echo "⚠️  Файл .env не найден"
    echo "📋 Скопируйте .env.example в .env и настройте подключение к базе данных"
    echo "💡 Пример: cp .env.example .env"
    echo ""
fi

echo "🔥 Запускаем сервер..."
echo "🌐 Сайт будет доступен по адресу: http://localhost:3000"
echo "👨‍💼 Админ-панель: http://localhost:3000/admin.html"
echo "🔑 По умолчанию: admin@example.com / admin123"
echo ""
echo "⏹️  Для остановки сервера нажмите Ctrl+C"
echo "=============================="

node server.js 