const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_here_change_this';

// Настройки базы данных
// ВНИМАНИЕ: Обновите эти настройки для вашей базы данных!
const pool = new Pool({
    host: process.env.DB_HOST || 'your-database-host.com',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'your_database_name',
    user: process.env.DB_USER || 'your_database_user',
    password: process.env.DB_PASSWORD || 'your_database_password',
    ssl: process.env.NODE_ENV === 'production' ? {
        rejectUnauthorized: false
    } : false
});

// Создаем папку uploads если её нет
const uploadsDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// Настройка multer для загрузки файлов
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadsDir)
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + path.extname(file.originalname))
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 5 * 1024 * 1024 // 5MB лимит
    },
    fileFilter: function (req, file, cb) {
        // Проверяем что файл - изображение
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        } else {
            cb(new Error('Только изображения разрешены!'), false);
        }
    }
});

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Middleware для проверки токена
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Токен не предоставлен' });
    }

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Недействительный токен' });
        }
        req.user = user;
        next();
    });
};

// Регистрация пользователя
app.post('/api/auth/register', async (req, res) => {
    try {
        const { email, password, phone, name } = req.body;

        // Проверяем обязательные поля
        if (!email || !password || !phone || !name) {
            return res.status(400).json({ error: 'Все поля обязательны для заполнения' });
        }

        // Проверяем, существует ли пользователь с таким email
        const existingUserByEmail = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
        if (existingUserByEmail.rows.length > 0) {
            return res.status(400).json({ error: 'Пользователь с таким email уже существует' });
        }

        // Проверяем, существует ли пользователь с таким телефоном
        const existingUserByPhone = await pool.query('SELECT id FROM users WHERE phone = $1', [phone]);
        if (existingUserByPhone.rows.length > 0) {
            return res.status(400).json({ error: 'Пользователь с таким телефоном уже существует' });
        }

        // Хешируем пароль
        const hashedPassword = await bcrypt.hash(password, 10);

        // Добавляем пользователя в базу данных
        const result = await pool.query(
            'INSERT INTO users (email, password_hash, phone, name, is_admin) VALUES ($1, $2, $3, $4, false) RETURNING id, email, phone, name, is_admin',
            [email, hashedPassword, phone, name]
        );

        const user = result.rows[0];

        // Создаем токен
        const token = jwt.sign({ 
            userId: user.id, 
            email: user.email,
            isAdmin: user.is_admin
        }, JWT_SECRET, { expiresIn: '24h' });

        res.json({
            message: 'Пользователь успешно зарегистрирован',
            user: {
                id: user.id,
                email: user.email,
                phone: user.phone,
                name: user.name,
                isAdmin: user.is_admin
            },
            token
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Ошибка при регистрации пользователя' });
    }
});

// Вход пользователя
app.post('/api/auth/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'Email и пароль обязательны' });
        }

        // Ищем пользователя
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        
        if (result.rows.length === 0) {
            return res.status(400).json({ error: 'Неверный email или пароль' });
        }

        const user = result.rows[0];

        // Проверяем пароль
        const isValidPassword = await bcrypt.compare(password, user.password_hash);
        
        if (!isValidPassword) {
            return res.status(400).json({ error: 'Неверный email или пароль' });
        }

        // Создаем токен
        const token = jwt.sign({ 
            userId: user.id, 
            email: user.email,
            isAdmin: user.is_admin
        }, JWT_SECRET, { expiresIn: '24h' });

        res.json({
            message: 'Успешный вход',
            user: {
                id: user.id,
                email: user.email,
                phone: user.phone,
                name: user.name,
                isAdmin: user.is_admin
            },
            token
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Ошибка при входе' });
    }
});

// Получить время последнего обновления объектов
app.get('/api/objects/last-update', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT MAX(updated_at) as last_update FROM objects WHERE is_active = true'
        );
        
        const lastUpdate = result.rows[0].last_update || new Date();
        
        res.json({
            lastUpdate: lastUpdate,
            timestamp: new Date().toISOString()
        });
    } catch (error) {
        console.error('Ошибка получения времени обновления:', error);
        res.status(500).json({ error: 'Ошибка сервера' });
    }
});

// Получение всех товаров
app.get('/api/objects', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT * FROM objects 
            WHERE status = 'active' 
            ORDER BY created_at DESC
        `);
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching objects:', error);
        res.status(500).json({ error: 'Ошибка при получении объектов' });
    }
});

// Получение конкретного товара
app.get('/api/objects/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query('SELECT * FROM objects WHERE id = $1', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Объект не найден' });
        }
        
        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching object:', error);
        res.status(500).json({ error: 'Ошибка при получении объекта' });
    }
});

// Добавление товара (только для админов)
app.post('/api/objects', authenticateToken, upload.array('images', 10), async (req, res) => {
    try {
        if (!req.user.isAdmin) {
            return res.status(403).json({ error: 'Доступ запрещен' });
        }

        const {
            type, title, description, price, location, area, living_area, kitchen_area,
            rooms, floor, max_floor, building_year, building_type, apartment_type,
            repair_type, bathroom_count, bathroom_type, balcony_count, balcony_type,
            window_view, parking_type, heating_type, gas_supply, nearest_metro,
            metro_distance_minutes, latitude, longitude, region, city, district,
            street, building_number, building_corpus, entrance, floor_in_building,
            apartment_number
        } = req.body;

        // Обработка загруженных изображений
        const images = req.files ? req.files.map(file => `/uploads/${file.filename}`) : [];

        const result = await pool.query(`
            INSERT INTO objects (
                type, title, description, price, location, area, living_area, kitchen_area,
                rooms, floor, max_floor, building_year, building_type, apartment_type,
                repair_type, bathroom_count, bathroom_type, balcony_count, balcony_type,
                window_view, parking_type, heating_type, gas_supply, nearest_metro,
                metro_distance_minutes, latitude, longitude, images, status, created_at,
                region, city, district, street, building_number, building_corpus,
                entrance, floor_in_building, apartment_number
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17,
                $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, 'active', NOW(),
                $29, $30, $31, $32, $33, $34, $35, $36, $37
            ) RETURNING *
        `, [
            type, title, description, parseFloat(price), location, parseFloat(area),
            living_area ? parseFloat(living_area) : null,
            kitchen_area ? parseFloat(kitchen_area) : null,
            rooms, floor ? parseInt(floor) : null, max_floor ? parseInt(max_floor) : null,
            building_year ? parseInt(building_year) : null, building_type, apartment_type,
            repair_type, bathroom_count ? parseInt(bathroom_count) : null, bathroom_type,
            balcony_count ? parseInt(balcony_count) : null, balcony_type, window_view,
            parking_type, heating_type, gas_supply, nearest_metro,
            metro_distance_minutes ? parseInt(metro_distance_minutes) : null,
            latitude ? parseFloat(latitude) : null, longitude ? parseFloat(longitude) : null,
            JSON.stringify(images), region, city, district, street, building_number,
            building_corpus, entrance, floor_in_building ? parseInt(floor_in_building) : null,
            apartment_number
        ]);

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error adding object:', error);
        res.status(500).json({ error: 'Ошибка при добавлении объекта' });
    }
});

// Обновление объекта недвижимости (только для админов)
app.put('/api/objects/:id', authenticateToken, upload.array('images', 10), async (req, res) => {
    try {
        if (!req.user.isAdmin) {
            return res.status(403).json({ error: 'Доступ запрещен' });
        }

        const { id } = req.params;
        const {
            type, title, description, price, location, area, living_area, kitchen_area,
            rooms, floor, max_floor, building_year, building_type, apartment_type,
            repair_type, bathroom_count, bathroom_type, balcony_count, balcony_type,
            window_view, parking_type, heating_type, gas_supply, nearest_metro,
            metro_distance_minutes, latitude, longitude, status, existingImages,
            region, city, district, street, building_number, building_corpus,
            entrance, floor_in_building, apartment_number
        } = req.body;

        // Обработка изображений
        let images = [];
        if (existingImages) {
            try {
                images = JSON.parse(existingImages);
            } catch (e) {
                images = [];
            }
        }

        // Добавляем новые изображения
        if (req.files && req.files.length > 0) {
            const newImages = req.files.map(file => `/uploads/${file.filename}`);
            images = images.concat(newImages);
        }

        const result = await pool.query(`
            UPDATE objects SET
                type = $1, title = $2, description = $3, price = $4, location = $5,
                area = $6, living_area = $7, kitchen_area = $8, rooms = $9, floor = $10,
                max_floor = $11, building_year = $12, building_type = $13, apartment_type = $14,
                repair_type = $15, bathroom_count = $16, bathroom_type = $17, balcony_count = $18,
                balcony_type = $19, window_view = $20, parking_type = $21, heating_type = $22,
                gas_supply = $23, nearest_metro = $24, metro_distance_minutes = $25,
                latitude = $26, longitude = $27, images = $28, status = $29,
                region = $30, city = $31, district = $32, street = $33, building_number = $34,
                building_corpus = $35, entrance = $36, floor_in_building = $37, apartment_number = $38
            WHERE id = $39 RETURNING *
        `, [
            type, title, description, parseFloat(price), location, parseFloat(area),
            living_area ? parseFloat(living_area) : null,
            kitchen_area ? parseFloat(kitchen_area) : null,
            rooms, floor ? parseInt(floor) : null, max_floor ? parseInt(max_floor) : null,
            building_year ? parseInt(building_year) : null, building_type, apartment_type,
            repair_type, bathroom_count ? parseInt(bathroom_count) : null, bathroom_type,
            balcony_count ? parseInt(balcony_count) : null, balcony_type, window_view,
            parking_type, heating_type, gas_supply, nearest_metro,
            metro_distance_minutes ? parseInt(metro_distance_minutes) : null,
            latitude ? parseFloat(latitude) : null, longitude ? parseFloat(longitude) : null,
            JSON.stringify(images), status || 'active', region, city, district, street,
            building_number, building_corpus, entrance,
            floor_in_building ? parseInt(floor_in_building) : null, apartment_number, id
        ]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Объект не найден' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating object:', error);
        res.status(500).json({ error: 'Ошибка при обновлении объекта' });
    }
});

// Удаление объекта недвижимости (только для админов)
app.delete('/api/objects/:id', authenticateToken, async (req, res) => {
    try {
        if (!req.user.isAdmin) {
            return res.status(403).json({ error: 'Доступ запрещен' });
        }

        const { id } = req.params;
        const result = await pool.query('DELETE FROM objects WHERE id = $1 RETURNING *', [id]);
        
        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Объект не найден' });
        }

        res.json({ message: 'Объект успешно удален' });
    } catch (error) {
        console.error('Error deleting object:', error);
        res.status(500).json({ error: 'Ошибка при удалении объекта' });
    }
});

// Получение всех объектов для админа
app.get('/api/admin/objects', authenticateToken, async (req, res) => {
    try {
        if (!req.user.isAdmin) {
            return res.status(403).json({ error: 'Доступ запрещен' });
        }

        const result = await pool.query(`
            SELECT * FROM objects 
            ORDER BY created_at DESC
        `);
        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching admin objects:', error);
        res.status(500).json({ error: 'Ошибка при получении объектов' });
    }
});

// Подача заявки на объект
app.post('/api/requests', authenticateToken, async (req, res) => {
    try {
        const { objectId, message } = req.body;
        const userId = req.user.userId;

        if (!objectId) {
            return res.status(400).json({ error: 'ID объекта обязателен' });
        }

        // Проверяем, существует ли объект
        const objectResult = await pool.query('SELECT id FROM objects WHERE id = $1', [objectId]);
        if (objectResult.rows.length === 0) {
            return res.status(404).json({ error: 'Объект не найден' });
        }

        // Создаем заявку
        const result = await pool.query(`
            INSERT INTO requests (user_id, object_id, message, status, created_at)
            VALUES ($1, $2, $3, 'new', NOW())
            RETURNING *
        `, [userId, objectId, message || '']);

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error creating request:', error);
        res.status(500).json({ error: 'Ошибка при создании заявки' });
    }
});

// Получение заявок пользователя
app.get('/api/user/requests', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;

        const result = await pool.query(`
            SELECT r.*, o.title as object_title, o.price as object_price, o.location as object_location
            FROM requests r
            JOIN objects o ON r.object_id = o.id
            WHERE r.user_id = $1
            ORDER BY r.created_at DESC
        `, [userId]);

        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching user requests:', error);
        res.status(500).json({ error: 'Ошибка при получении заявок' });
    }
});

// Получение всех заявок для админа
app.get('/api/admin/requests', authenticateToken, async (req, res) => {
    try {
        if (!req.user.isAdmin) {
            return res.status(403).json({ error: 'Доступ запрещен' });
        }

        const result = await pool.query(`
            SELECT r.*, u.name as user_name, u.email as user_email, u.phone as user_phone,
                   o.title as object_title, o.price as object_price, o.location as object_location
            FROM requests r
            JOIN users u ON r.user_id = u.id
            JOIN objects o ON r.object_id = o.id
            ORDER BY r.created_at DESC
        `);

        res.json(result.rows);
    } catch (error) {
        console.error('Error fetching admin requests:', error);
        res.status(500).json({ error: 'Ошибка при получении заявок' });
    }
});

// Обновление статуса заявки (только для админов)
app.put('/api/requests/:id/status', authenticateToken, async (req, res) => {
    try {
        if (!req.user.isAdmin) {
            return res.status(403).json({ error: 'Доступ запрещен' });
        }

        const { id } = req.params;
        const { status } = req.body;

        if (!['new', 'in_progress', 'completed', 'rejected'].includes(status)) {
            return res.status(400).json({ error: 'Недопустимый статус' });
        }

        const result = await pool.query(
            'UPDATE requests SET status = $1 WHERE id = $2 RETURNING *',
            [status, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Заявка не найдена' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating request status:', error);
        res.status(500).json({ error: 'Ошибка при обновлении статуса заявки' });
    }
});

// Изменение статуса объекта (только для админов)
app.put('/api/objects/:id/status', authenticateToken, async (req, res) => {
    try {
        if (!req.user.isAdmin) {
            return res.status(403).json({ error: 'Доступ запрещен' });
        }

        const { id } = req.params;
        const { status } = req.body;

        if (!['active', 'inactive'].includes(status)) {
            return res.status(400).json({ error: 'Недопустимый статус' });
        }

        const result = await pool.query(
            'UPDATE objects SET status = $1 WHERE id = $2 RETURNING *',
            [status, id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Объект не найден' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating object status:', error);
        res.status(500).json({ error: 'Ошибка при обновлении статуса объекта' });
    }
});

// Получение информации о пользователе
app.get('/api/user/profile', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        
        const result = await pool.query(
            'SELECT id, email, phone, name, is_admin FROM users WHERE id = $1',
            [userId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error fetching user profile:', error);
        res.status(500).json({ error: 'Ошибка при получении профиля' });
    }
});

// Обновление профиля пользователя
app.put('/api/user/profile', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { name, phone } = req.body;

        if (!name || !phone) {
            return res.status(400).json({ error: 'Имя и телефон обязательны' });
        }

        // Проверяем, не занят ли телефон другим пользователем
        const existingUser = await pool.query(
            'SELECT id FROM users WHERE phone = $1 AND id != $2',
            [phone, userId]
        );

        if (existingUser.rows.length > 0) {
            return res.status(400).json({ error: 'Этот телефон уже используется' });
        }

        const result = await pool.query(
            'UPDATE users SET name = $1, phone = $2 WHERE id = $3 RETURNING id, email, phone, name, is_admin',
            [name, phone, userId]
        );

        res.json(result.rows[0]);
    } catch (error) {
        console.error('Error updating profile:', error);
        res.status(500).json({ error: 'Ошибка при обновлении профиля' });
    }
});

// Смена пароля
app.put('/api/user/password', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { currentPassword, newPassword } = req.body;

        if (!currentPassword || !newPassword) {
            return res.status(400).json({ error: 'Оба пароля обязательны' });
        }

        // Получаем текущий хеш пароля
        const userResult = await pool.query('SELECT password_hash FROM users WHERE id = $1', [userId]);
        
        if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }

        // Проверяем текущий пароль
        const isValidPassword = await bcrypt.compare(currentPassword, userResult.rows[0].password_hash);
        
        if (!isValidPassword) {
            return res.status(400).json({ error: 'Неверный текущий пароль' });
        }

        // Хешируем новый пароль
        const hashedNewPassword = await bcrypt.hash(newPassword, 10);

        // Обновляем пароль
        await pool.query('UPDATE users SET password_hash = $1 WHERE id = $2', [hashedNewPassword, userId]);

        res.json({ message: 'Пароль успешно изменен' });
    } catch (error) {
        console.error('Error changing password:', error);
        res.status(500).json({ error: 'Ошибка при смене пароля' });
    }
});

// Удаление аккаунта
app.delete('/api/user/account', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { password } = req.body;

        if (!password) {
            return res.status(400).json({ error: 'Пароль обязателен для удаления аккаунта' });
        }

        // Получаем пользователя
        const userResult = await pool.query('SELECT password_hash, is_admin FROM users WHERE id = $1', [userId]);
        
        if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'Пользователь не найден' });
        }

        const user = userResult.rows[0];

        // Проверяем, что это не администратор
        if (user.is_admin) {
            return res.status(400).json({ error: 'Аккаунт администратора нельзя удалить' });
        }

        // Проверяем пароль
        const isValidPassword = await bcrypt.compare(password, user.password_hash);
        
        if (!isValidPassword) {
            return res.status(400).json({ error: 'Неверный пароль' });
        }

        // Удаляем связанные заявки
        await pool.query('DELETE FROM requests WHERE user_id = $1', [userId]);

        // Удаляем пользователя
        await pool.query('DELETE FROM users WHERE id = $1', [userId]);

        res.json({ message: 'Аккаунт успешно удален' });
    } catch (error) {
        console.error('Error deleting account:', error);
        res.status(500).json({ error: 'Ошибка при удалении аккаунта' });
    }
});

// API для автозаполнения адресов
app.get('/api/addresses/regions', async (req, res) => {
    try {
        const { query } = req.query;
        // Здесь можно подключить реальную базу регионов или API
        // Пока возвращаем моковые данные
        const regions = [
            'Москва', 'Московская область', 'Санкт-Петербург', 'Ленинградская область',
            'Краснодарский край', 'Республика Татарстан', 'Свердловская область',
            'Новосибирская область', 'Республика Башкортостан', 'Нижегородская область'
        ];
        
        const filtered = query 
            ? regions.filter(region => region.toLowerCase().includes(query.toLowerCase()))
            : regions;
            
        res.json(filtered.slice(0, 10));
    } catch (error) {
        console.error('Error fetching regions:', error);
        res.status(500).json({ error: 'Ошибка при получении регионов' });
    }
});

app.get('/api/addresses/cities/:region', async (req, res) => {
    try {
        const { region } = req.params;
        const { query } = req.query;
        
        // Моковые данные для городов
        const citiesByRegion = {
            'Москва': ['Москва'],
            'Московская область': ['Балашиха', 'Подольск', 'Химки', 'Мытищи', 'Королёв', 'Люберцы'],
            'Санкт-Петербург': ['Санкт-Петербург'],
            'Краснодарский край': ['Краснодар', 'Сочи', 'Новороссийск', 'Анапа', 'Геленджик']
        };
        
        const cities = citiesByRegion[region] || [];
        const filtered = query 
            ? cities.filter(city => city.toLowerCase().includes(query.toLowerCase()))
            : cities;
            
        res.json(filtered.slice(0, 10));
    } catch (error) {
        console.error('Error fetching cities:', error);
        res.status(500).json({ error: 'Ошибка при получении городов' });
    }
});

// Инициализация базы данных
async function initDatabase() {
    try {
        console.log('🔄 Подключение к базе данных...');
        
        // Проверяем подключение
        await pool.query('SELECT NOW()');
        console.log('✅ Подключение к PostgreSQL успешно:', new Date().toISOString());

        // Создаем таблицу пользователей
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                phone VARCHAR(20) UNIQUE NOT NULL,
                name VARCHAR(255) NOT NULL,
                is_admin BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log('📋 Таблица users проверена/создана');

        // Создаем таблицу объектов недвижимости
        await pool.query(`
            CREATE TABLE IF NOT EXISTS objects (
                id SERIAL PRIMARY KEY,
                type VARCHAR(50) NOT NULL,
                title VARCHAR(255) NOT NULL,
                description TEXT,
                price DECIMAL(15,2) NOT NULL,
                location VARCHAR(255) NOT NULL,
                area DECIMAL(10,2),
                living_area DECIMAL(10,2),
                kitchen_area DECIMAL(10,2),
                rooms VARCHAR(20),
                floor INTEGER,
                max_floor INTEGER,
                building_year INTEGER,
                building_type VARCHAR(100),
                apartment_type VARCHAR(100),
                repair_type VARCHAR(100),
                bathroom_count INTEGER,
                bathroom_type VARCHAR(100),
                balcony_count INTEGER,
                balcony_type VARCHAR(100),
                window_view VARCHAR(100),
                parking_type VARCHAR(100),
                heating_type VARCHAR(100),
                gas_supply VARCHAR(100),
                nearest_metro VARCHAR(255),
                metro_distance_minutes INTEGER,
                latitude DECIMAL(10,8),
                longitude DECIMAL(11,8),
                images TEXT,
                status VARCHAR(20) DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        // Добавляем новые колонки для адреса если их нет
        try {
            await pool.query(`
                ALTER TABLE objects 
                ADD COLUMN IF NOT EXISTS region VARCHAR(255),
                ADD COLUMN IF NOT EXISTS city VARCHAR(255),
                ADD COLUMN IF NOT EXISTS district VARCHAR(255),
                ADD COLUMN IF NOT EXISTS street VARCHAR(255),
                ADD COLUMN IF NOT EXISTS building_number VARCHAR(50),
                ADD COLUMN IF NOT EXISTS building_corpus VARCHAR(50),
                ADD COLUMN IF NOT EXISTS entrance VARCHAR(50),
                ADD COLUMN IF NOT EXISTS floor_in_building INTEGER,
                ADD COLUMN IF NOT EXISTS apartment_number VARCHAR(50)
            `);
            console.log('✅ Столбцы адреса добавлены/обновлены в objects');
        } catch (error) {
            console.log('ℹ️ Столбцы адреса уже существуют');
        }

        console.log('🏠 Таблица objects проверена/создана');

        // Создаем таблицу заявок
        await pool.query(`
            CREATE TABLE IF NOT EXISTS requests (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
                object_id INTEGER REFERENCES objects(id) ON DELETE CASCADE,
                message TEXT,
                status VARCHAR(20) DEFAULT 'new',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log('📝 Таблица requests проверена/создана');

        // Создаем администратора по умолчанию
        try {
            const adminEmail = 'admin@example.com';
            const adminPassword = 'admin123'; // Замените на безопасный пароль
            
            // Проверяем, есть ли уже администратор
            const existingAdmin = await pool.query('SELECT id FROM users WHERE email = $1', [adminEmail]);
            
            if (existingAdmin.rows.length === 0) {
                const hashedPassword = await bcrypt.hash(adminPassword, 10);
                await pool.query(
                    'INSERT INTO users (email, password_hash, phone, name, is_admin) VALUES ($1, $2, $3, $4, true)',
                    [adminEmail, hashedPassword, '+7(000)000-00-00', 'Администратор']
                );
                console.log(`👤 Создан администратор: ${adminEmail} / ${adminPassword}`);
            } else {
                console.log('👤 Администратор уже существует');
            }
        } catch (error) {
            console.log('⚠️ Ошибка при создании администратора:', error.message);
        }

        console.log('🚀 Инициализация базы данных завершена');

    } catch (error) {
        console.error('❌ Ошибка при инициализации базы данных:', error);
        process.exit(1);
    }
}

// Запуск сервера
async function startServer() {
    await initDatabase();
    
    app.listen(PORT, () => {
        console.log(`🚀 Сервер запущен на http://localhost:${PORT}`);
        console.log('🏠 Используется PostgreSQL база данных');
    });
}

startServer(); 